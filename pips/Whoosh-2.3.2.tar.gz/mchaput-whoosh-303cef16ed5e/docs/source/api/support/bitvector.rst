============================
``support.bitvector`` module
============================

.. automodule:: whoosh.support.bitvector

.. autoclass:: BitVector
	:members:

