==================
``reading`` module
==================

.. automodule:: whoosh.reading

Classes
=======

.. autoclass:: IndexReader
    :members:
    
.. autoclass:: MultiReader


Exceptions
==========

.. autoexception:: TermNotFound

