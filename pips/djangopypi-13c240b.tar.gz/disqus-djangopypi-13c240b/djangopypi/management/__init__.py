# Ensure signals get registered
from djangopypi import signals
